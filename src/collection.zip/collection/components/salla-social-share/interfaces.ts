export enum Socials {
    FACEBOOK = "facebook",
    TWITTER = "twitter",
    WHATSAPP = "whatsapp",
    EMAIL = "email",
    COPY_LINK = "copy_link"
}