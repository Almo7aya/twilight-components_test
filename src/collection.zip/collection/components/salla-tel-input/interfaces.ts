export interface Phone {
    country_code: string;
    number: string;
}