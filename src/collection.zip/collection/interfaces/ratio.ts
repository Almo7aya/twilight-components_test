export type Ratio = '1x1' | '5x4' | '5x3' | '3x2' | '16x9' | '2x1' | '3x1';
