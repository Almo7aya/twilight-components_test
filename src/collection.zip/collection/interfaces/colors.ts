export type Color = 'primary' | 'secondary' | 'success' | 'warning' | 'error' | 'info' | 'default';
